import React, { useState } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import Slider from 'react-slick';
import QRCodeModal from './QRCodeModal';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const ValidTicket = ({ tickets }) => {
  const [activeTicket, setActiveTicket] = useState(null); // Track the ticket to show in the modal

  const openModal = (ticket) => {
    setActiveTicket(ticket);
  };

  const closeModal = () => {
    setActiveTicket(null);
  };

  const sliderSettings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    centerMode: true,    // Centers the active slide
    centerPadding: '10%', // Space around the active slide (adjust for design)
  };

  return (
    <div className="slider-container">
      <Slider {...sliderSettings}>
        {tickets.map((ticket, index) => (
          <div key={index} className="ticket-card">
            <div className="qr-code-wrapper">
              <QRCodeCanvas value={JSON.stringify(ticket)} size={200} />
            </div>
            <div className="ticket-details">
              <p>{ticket.bar_name}</p>
              <p>{ticket.name}</p>
              <p>Valid until: {new Date(ticket.datetime_invalid).toLocaleString()}</p>
            </div>
            <button
              className="expand-button"
              onClick={() => openModal(ticket)} // Pass the ticket to the modal
            >
              Expand
            </button>
          </div>
        ))}
      </Slider>
      {/* Render the QRCodeModal */}
      {activeTicket && (
        <QRCodeModal
          ticket={activeTicket}
          isOpen={!!activeTicket} // Modal is open when there's an active ticket
          onClose={closeModal} // Close modal when X is clicked
        />
      )}
    </div>
  );
};

export default ValidTicket;