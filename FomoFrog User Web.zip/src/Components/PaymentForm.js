import React, { useState, useContext } from 'react';
import { FaTimes } from 'react-icons/fa';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
import { UserContext } from '../Contexts/UserContext';
import '../index.css';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const phoneRegex = /^\d{10}$/;
const nameRegex = /^[a-zA-Z\s'-]{1,50}$/;

const PaymentForm = ({ barId, barName, hopPrice, fein, closePayment, barState, quantity }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { user } = useContext(UserContext);
  const [isLoading, setIsLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [ticketDetails, setTicketDetails] = useState(
    Array(quantity).fill({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      isForLoggedInUser: false,
    })
  );

  const handleInputChange = (index, field, value) => {
    setTicketDetails((prevDetails) => {
      const updatedDetails = [...prevDetails];
      updatedDetails[index][field] = value;
      return updatedDetails;
    });
  };

  const handleCheckboxChange = (index) => {
    setTicketDetails((prevDetails) => {
      const updatedDetails = prevDetails.map((ticket, i) => {
        if (i === index) {
          // Toggle the current checkbox
          return {
            ...ticket,
            isForLoggedInUser: !ticket.isForLoggedInUser,
            ...(ticket.isForLoggedInUser
              ? { name: '', email: '', phone: '' } // Reset fields when unchecked
              : user && {
                  firstName: user.firstName,
                  lastName: user.lastName,
                  email: user.email,
                  phone: user.phone,
                }),
          };
        } else {
          // Uncheck all other checkboxes
          return {
            ...ticket,
            isForLoggedInUser: false,
          };
        }
      });
      return updatedDetails;
    });
  };  

  const handleSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
  
    if (!stripe || !elements) {
      setIsLoading(false);
      return;
    }
  
    // Input validation
    for (let i = 0; i < ticketDetails.length; i++) {
      const { firstName, lastName, email, phone, isForLoggedInUser } = ticketDetails[i];
  
      if (!isForLoggedInUser) {
        if (!nameRegex.test(firstName)) {
          alert(`Please enter a valid first name for Ticket ${i + 1}.`);
          setIsLoading(false);
          return;
        }
        if (!nameRegex.test(lastName)) {
          alert(`Please enter a valid last name for Ticket ${i + 1}.`);
          setIsLoading(false);
          return;
        }
        if (!emailRegex.test(email)) {
          alert(`Please enter a valid email for Ticket ${i + 1}.`);
          setIsLoading(false);
          return;
        }
        if (!phoneRegex.test(phone)) {
          alert(`Please enter a valid 10-digit phone number for Ticket ${i + 1}.`);
          setIsLoading(false);
          return;
        }
      }
    }
  
    const cardElement = elements.getElement(CardElement);
  
    // Calculate the total price
    const totalPrice = Math.round((hopPrice * quantity * 1.0825) * 100) / 100;
  
    try {
      // Call your backend to create a PaymentIntent
      const response = await fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/handleStripePayment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.REACT_APP_BASE_API_KEY,
        },
        body: JSON.stringify({
          action: 'createPaymentIntent',
          price: totalPrice,
          fein,
          bar_id: barId,
          tickets: ticketDetails,
          bar_name: barName,
        }),
      });
  
      const responseData = await response.json();
      const clientSecret = responseData.clientSecret;
  
      if (!clientSecret) {
        throw new Error('Failed to retrieve client secret from server');
      }
  
      // Confirm the payment
      const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
        },
      });
  
      if (error) {
        console.error('Payment failed:', error);
        setPaymentStatus('failed');
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        console.log('Payment succeeded!');
        setPaymentStatus('succeeded');
  
        // Handle successful payment and create tickets
        const ticketResponse = await fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/createTicket`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
          },
          body: JSON.stringify({
            action: 'createTickets',
            paymentIntentId: paymentIntent.id,
            fein,
            bar_id: barId,
            tickets: ticketDetails.map((ticket) => ({
              firstName: ticket.firstName,
              lastName: ticket.lastName,
              email: ticket.email,
              phone: ticket.phone,
            })),
            bar_name: barName,
          }),
        });
  
        const ticketData = await ticketResponse.json();
        const tickets = ticketData.tickets;
  
        // Store tickets in localStorage for guest users
        if (!user && tickets) {
          const storedTickets = JSON.parse(localStorage.getItem('tickets')) || [];
          tickets.forEach((ticket) => {
            if (ticket) storedTickets.push(ticket);
          });
          localStorage.setItem('tickets', JSON.stringify(storedTickets));
        }
  
        closePayment();
      }
    } catch (error) {
      console.error('Error:', error);
      setPaymentStatus('failed');
    } finally {
      setIsLoading(false);
    }
  };  

  return (
    <div className="payment-form-overlay">
      <div className="payment-form-container">
        <div className="payment-form-header">
          <FaTimes className="close-icon" onClick={closePayment} />
        </div>
        <form onSubmit={handleSubmit} className="payment-form">
          <h2>Enter Ticket Details</h2>
          {ticketDetails.map((ticket, index) => (
            <div key={index} className="ticket-entry">
              <h3>Ticket {index + 1}</h3>
              {user && (
                <div className="checkbox-container">
                  <input
                    type="checkbox"
                    id={`ticket-${index}`}
                    checked={ticket.isForLoggedInUser}
                    onChange={() => handleCheckboxChange(index)}
                  />
                  <label htmlFor={`ticket-${index}`}>Use my information</label>
                </div>
              )}
              {!ticket.isForLoggedInUser && (
                <div className='ticket-entry-item'>
                  <input
                    type="text"
                    placeholder="First Name"
                    value={ticket.firstName}
                    onChange={(e) => handleInputChange(index, 'firstName', e.target.value)}
                    required
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    value={ticket.lastName}
                    onChange={(e) => handleInputChange(index, 'lastName', e.target.value)}
                    required
                  />
                  <input
                    type="email"
                    placeholder="Email"
                    value={ticket.email}
                    onChange={(e) => handleInputChange(index, 'email', e.target.value)}
                    required
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    value={ticket.phone}
                    onChange={(e) => handleInputChange(index, 'phone', e.target.value)}
                    required
                  />
                </div>
              )}
            </div>
          ))}
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                },
              },
            }}
          />
          <button type="submit" disabled={!stripe || isLoading} className="pay-button">
            {isLoading ? 'Processing...' : `Pay $${(hopPrice * quantity * 1.0825).toFixed(2)}`}
          </button>
        </form>
              {paymentStatus && (
                <div
                  className={`payment-status ${
                    paymentStatus === 'succeeded' ? 'success' : 'failure'
                  }`}
                >
                  {paymentStatus === 'succeeded'
                    ? 'Payment successful! Generating Hop pass.'
                    : 'Payment failed. Please try again.'}
                </div>
              )}
      </div>
    </div>
  );
};

export default PaymentForm;