import React, { useEffect } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { FaTimes } from 'react-icons/fa';

function QRCodeModal({ ticket, isOpen, onClose }) {
  // Prevent background scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto'; // Clean up on unmount
    };
  }, [isOpen]);

  return (
    <div className="modal-overlay" aria-hidden={!isOpen} onClick={onclose}>
      <div className="qr-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes
            className="close-icon"
            onClick={onClose}
            aria-label="Close Modal"
            tabIndex="0"
          />
        </div>
        <div className="qr-code-wrapper">
          <QRCodeCanvas value={JSON.stringify(ticket)} size={300} />
        </div>
        <div className="ticket-details">
          <p>{ticket.bar_name}</p>
          <p>{ticket.name}</p>
          <p>Valid until: {new Date(ticket.datetime_invalid).toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}

export default QRCodeModal;
