import React from 'react';
import '../index.css';
import { FaTimes } from 'react-icons/fa';

const ReviewPoliciesModal = ({ isOpen, onClose }) => {
    const termsUrl = `${process.env.REACT_APP_TERMS_AND_CONDITIONS}FomoFrog_Terms_and_Conditions.pdf`;
    const privacyPolicyUrl = `${process.env.REACT_APP_PRIVACY_POLICY}FomoFrog_Privacy_Policy.pdf`;

    const handleTermsClick = (item) => {
        window.open(item, '_blank'); // Opens the terms in a new tab
      };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <div className="policy-tiles">
            <div className="profile-tile" onClick={() => handleTermsClick(termsUrl)}>View Terms and Conditions</div>
            <div className="profile-tile" onClick={() => handleTermsClick(privacyPolicyUrl)}>Learn about FomoFrog's Privacy Policy</div>
          </div>
        </div>
      </div> 
    </div>
  );
};

export default ReviewPoliciesModal;