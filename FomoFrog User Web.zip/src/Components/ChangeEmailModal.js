import React, { useContext, useState } from 'react';
import '../index.css';
import { UserContext } from '../Contexts/UserContext';
import { FaTimes } from 'react-icons/fa';
import axios from 'axios';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const ChangeEmailModal = ({ isOpen, onClose }) => {
  const { user, setUser } = useContext(UserContext); // Access user info and a function to update it
  const [email, setEmail] = useState(user?.email || '');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSave = async () => {
    // Clear previous error messages
    setErrorMessage('');

    if (email.trim() === user.email) {
      setErrorMessage('No changes detected. Please enter a different email.');
      return;
    }

    if (!emailRegex.test(email.trim())) {
      setErrorMessage('Invalid email format. Please enter a valid email.');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found in local storage');
      setErrorMessage('Authorization error. Please log in again.');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/changeEmail`,
        {
          oldEmail: user.email,
          newEmail: email.trim(),
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
          },
        }
      );

      if (response.status === 200) {
        // Update user context with the new email
        setUser({ ...user, email: email.trim() });
        window.alert('Email updated successfully.');
        onClose();
      } else {
        // Handle specific error messages from the backend
        const errorMessage = response.data.message || 'Failed to change email.';
        setErrorMessage(errorMessage);
      }
    } catch (error) {
      console.error('Error changing email:', error);
      setErrorMessage(
        error.response?.data?.message ||
          'An unexpected error occurred. Please try again later.'
      );
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes
            className="close-icon"
            style={{ color: 'var(--text-color)' }}
            onClick={onClose}
          />
        </div>
        <div className="modal-content">
          <h2 className="modal-title">Edit Account Email</h2>
          <form className="contact-info-form" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input-field"
              disabled={loading}
              required
            />
          </form>
          {errorMessage && <div className="error-message">{errorMessage}</div>}
          <button
            className={`button-primary ${loading ? 'loading' : ''}`}
            onClick={handleSave}
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChangeEmailModal;