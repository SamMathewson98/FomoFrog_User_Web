import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { FaTimes } from 'react-icons/fa';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import '../index.css';
import PaymentFormFour from './PaymentFormFour';

// Load Stripe outside of the component to avoid re-initializing on every render
const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

const BarModal = ({ bar, isOpen, onClose }) => {
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [quantity, setQuantity] = useState(1); // Default ticket quantity is 1

  if (!isOpen || !bar) return null;

  const handlePaymentClick = () => {
    setShowPaymentForm(true);
  };

  const closePayment = () => {
    setShowPaymentForm(false);
  };

  const incrementQuantity = () => {
    setQuantity((prev) => Math.min(prev + 1, 10)); // Max tickets: 10
  };

  const decrementQuantity = () => {
    setQuantity((prev) => Math.max(prev - 1, 1)); // Min tickets: 1
  };

  const totalPrice = Math.round(bar.priceToHop * quantity * 1.0825 * 100); // Total in cents

  const options = {
    mode: 'payment',
    amount: totalPrice,
    currency: 'usd',
    appearance: {
      variables: {
        // This controls the border-radius of the rendered Express Checkout Element
        borderRadius: '5px'
      }
    }
  };

  // The modal content
  const modalContent = (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="bar-modal-header">
          <img
            src={bar.cover_photo_url ? bar.cover_photo_url : '/Default Cover Photo.webp'}
            alt="Cover Photo"
            className="cover-photo"
          />
          <FaTimes className="bar-modal-close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          {!showPaymentForm ? (
            <>
              <div className="bar-header">
                <img
                  src={bar.icon_url ? bar.icon_url : '/FomoFrog logo.webp'}
                  alt="Bar Logo"
                  className="bar-logo-modal"
                />
                <div className="bar-info">
                  <div className="bar-name-modal">{bar.venueName}</div>
                  <div className="bar-address-modal">
                    {`${bar.address.addressLine1}${bar.address.addressLine2 ? ', ' + bar.address.addressLine2 : ''}, ${
                      bar.address.city
                    }, ${bar.address.state} ${bar.address.zipCode}`}
                  </div>
                  {bar.distance && (
                    <div className="bar-distance-modal">{`${bar.distance.toFixed(1)} miles away`}</div>
                  )}
                </div>
                <div className="price-and-website">
                  {bar.website_url && (
                    <a href={bar.website_url} target="_blank" rel="noopener noreferrer" className="bar-website">
                      Visit Website
                    </a>
                  )}
                </div>
              </div>
              <div className="pay-area">
                <div className="ticket-quantity">
                  <button className="quantity-button" onClick={decrementQuantity}>
                    -
                  </button>
                  <span className="quantity-display">{quantity}</span>
                  <button className="quantity-button" onClick={incrementQuantity}>
                    +
                  </button>
                </div>
                <div className="pay-button-container">
                  <button className="pay-button" onClick={handlePaymentClick}>
                    Pay ${(bar.priceToHop * quantity).toFixed(2)}
                  </button>
                </div>
              </div>
              <p className="fine-print">
                FomoFrog is not responsible for adherence to dresscode, age restrictions, open or closing time,
                personal conduct or any other venue-based restrictions that may prohibit access to the fun. Tickets not
                honored due to venue-based restrictions are non-refundable. Act kindly, show respect, and have fun
                responsibly!
              </p>
              <div className="modal-body">
                <div className="hours-column">
                  <h3>Hours of Operation</h3>
                  {bar.hoursOfOperation &&
                    Object.entries(bar.hoursOfOperation).map(([day, hours]) => (
                      <div key={day} className="bar-hours">
                        <strong>{day.charAt(0).toUpperCase() + day.slice(1)}:</strong> {hours}
                      </div>
                    ))}
                </div>
                <div className="description-column">
                  <h3>About</h3>
                  <p>{bar.description}</p>
                </div>
              </div>
            </>
          ) : (
            <Elements stripe={stripePromise} options={options}>
              {stripePromise ? (
                <PaymentFormFour
                  barId={bar.bar_id}
                  barName={bar.venueName}
                  totalPrice={totalPrice}
                  fein={bar.fein}
                  closePayment={closePayment}
                  barState={bar.address.state}
                  quantity={quantity} // Pass quantity to PaymentForm
                />
              ) : (
                <p>Loading payment form...</p>
              )}
            </Elements>
          )}
        </div>
      </div>
    </div>
  );

  // Render the modal using React Portal
  return ReactDOM.createPortal(modalContent, document.body);
};

export default BarModal;