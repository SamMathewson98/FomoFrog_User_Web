import React, { useState } from 'react';
import '../index.css';

const LoadingButton = ({ onClick, children, disabled }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    setIsLoading(true);
    try {
      await onClick();
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handleClick}
      disabled={disabled || isLoading}
      className={`loading-button ${isLoading ? 'loading' : ''}`}
    >
      {isLoading ? <div className="spinner"></div> : children}
    </button>
  );
};

export default LoadingButton;