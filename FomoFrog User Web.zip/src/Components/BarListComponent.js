import React, { useState } from 'react';
import '../index.css';
import BarModal from './BarModal';

const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const toRad = (value) => (value * Math.PI) / 180;

  const R = 3959; // Radius of the Earth in miles
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in miles
};

const BarListComponent = ({ bars, userLocation }) => {
  const [selectedBar, setSelectedBar] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = (bar) => {
    setSelectedBar(bar);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedBar(null);
    setIsModalOpen(false);
  };

  // Sort bars by distance if user location is available
  const sortedBars = userLocation
    ? [...bars].sort((a, b) =>
        calculateDistance(userLocation[0], userLocation[1], a.latitude, a.longitude) -
        calculateDistance(userLocation[0], userLocation[1], b.latitude, b.longitude)
      )
    : bars;

  return (
    <div className="bar-list">
      {sortedBars.map((bar) => {
        const distance = userLocation
          ? calculateDistance(userLocation[0], userLocation[1], bar.latitude, bar.longitude)
          : null;

        return (
          <div key={bar.bar_id} className="bar-item" onClick={() => openModal({ ...bar, distance })}>
            <img src={bar.icon_url ? bar.icon_url : '/FomoFrog logo.webp'} alt="Bar Logo" className="bar-logo-modal" />
            <div className="bar-details">
              <div className="bar-name">{bar.venueName}</div>
              <div className="bar-address">
                {`${bar.address.addressLine1}${bar.address.addressLine2 ? ', ' + bar.address.addressLine2 : ''}, ${bar.address.city}, ${bar.address.state} ${bar.address.zipCode}`}
                {userLocation && distance && (
                  <span className="bar-distance"> - {`${distance.toFixed(1)} miles away`}</span>
                )}
              </div>
            </div>
            <div className="bar-price">
              {bar.priceToHop ? `$${bar.priceToHop}` : 'Coming Soon'}
            </div>
          </div>
        );
      })}
      <BarModal bar={selectedBar} isOpen={isModalOpen} onClose={closeModal} />
    </div>
  );
};

export default BarListComponent;