import React, { useContext, useState } from 'react';
import '../index.css';
import { UserContext } from '../Contexts/UserContext';
import { FaTimes } from 'react-icons/fa';
import axios from 'axios';

const ContactSupportModal = ({ isOpen, onClose }) => {
  const { user } = useContext(UserContext);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [supportRequest, setSupportRequest] = useState({
    requestType: 'Support Request',
    message: '',
    email: user?.email || '',
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    phone: user?.phone || '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSupportRequest((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    const { requestType, message, email, firstName, lastName, phone } = supportRequest;

    if (!message.trim()) {
      alert('Please provide details about your request.');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found in local storage');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/contactSupport`,
        {
          email,
          name: `${firstName} ${lastName}`,
          phone,
          requestType,
          message,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
          },
        }
      );

      if (response.status === 200) {
        setSuccessMessage('Your request has been submitted successfully!');
        setTimeout(() => {
          setSuccessMessage('');
          onClose();
        }, 3000);
      } else {
        console.error('Failed to submit support request:', response);
        alert('Failed to submit support request. Please try again later.');
      }
    } catch (error) {
      console.error('Error submitting support request:', error);
      alert('An error occurred while submitting your request. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2 className='modal-title'>Contact Support</h2>
          <form className="contact-info-form">
            {user ? (
              <>
              </>
            ) : (
              <>
                <div className="input-group">
                  <label>Email</label>
                  <input
                    type="email"
                    name="email"
                    value={supportRequest.email}
                    onChange={handleChange}
                    className="input-field"
                  />
                </div>
                <div className="input-group">
                  <label>First Name</label>
                  <input
                    type="text"
                    name="firstName"
                    value={supportRequest.firstName}
                    onChange={handleChange}
                    className="input-field"
                  />
                </div>
                <div className="input-group">
                  <label>Last Name</label>
                  <input
                    type="text"
                    name="lastName"
                    value={supportRequest.lastName}
                    onChange={handleChange}
                    className="input-field"
                  />
                </div>
                <div className="input-group">
                  <label>Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={supportRequest.phone}
                    onChange={handleChange}
                    className="input-field"
                  />
                </div>
              </>
            )}
            <label>Request Type</label>
            <select
              name="requestType"
              value={supportRequest.requestType}
              onChange={handleChange}
              className="input-field"
            >
              <option value="Support Request">Support Request</option>
              <option value="Feature Request">Feature Request</option>
              <option value="Payment Inquiry">Payment Inquiry</option>
              <option value="Other">Other</option>
            </select>
            <label>Details</label>
            <textarea
              name="message"
              value={supportRequest.message}
              onChange={handleChange}
              className="input-field textarea-field"
              rows="5"
              placeholder="Please describe your issue or request..."
            />
          </form>
          {successMessage && <div className="success-message">{successMessage}</div>}
          <button className="button-primary" onClick={handleSubmit} disabled={loading}>
            {loading ? 'Submitting...' : 'Submit'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactSupportModal;