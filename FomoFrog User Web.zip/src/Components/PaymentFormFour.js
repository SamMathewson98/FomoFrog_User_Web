import React, { useState, useContext, useEffect } from 'react';
import {useStripe, useElements, ExpressCheckoutElement, CardElement} from '@stripe/react-stripe-js';
import { UserContext } from '../Contexts/UserContext';
import '../index.css';
import { FaTimes, FaSpinner } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const phoneRegex = /^\d{10}$/;
const nameRegex = /^[a-zA-Z\s'-]{1,50}$/;

const PaymentFormFour = ({ barId, barName, fein, closePayment, barState, totalPrice, quantity }) => {
    const stripe = useStripe();
    const elements = useElements();
    const { user } = useContext(UserContext);
    const [visibility, setVisibility] = useState('hidden');
    const [errorMessage, setErrorMessage] = useState();
    const [isLoading, setIsLoading] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState(null);
    const [clientSecret, setClientSecret] = useState(null);
    const [ticketDetails, setTicketDetails] = useState(
        Array(quantity).fill({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          isForLoggedInUser: false,
        })
      );
    const navigate = useNavigate();

      console.log(totalPrice);

      useEffect(() => {
        // Create PaymentIntent as soon as the page loads
        fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/createPaymentIntent`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            price: totalPrice, // Total price in cents
            fein,
            bar_id: barId,
            bar_name: barName,
          }),
        })
          .then((res) => res.json())
          .then((data) => setClientSecret(data.clientSecret));
      }, []);

      const handleInputChange = (index, field, value) => {
        setTicketDetails((prevDetails) => {
          const updatedDetails = [...prevDetails];
          updatedDetails[index][field] = value;
          return updatedDetails;
        });
      };
    
      const handleCheckboxChange = (index) => {
        setTicketDetails((prevDetails) => {
          const updatedDetails = prevDetails.map((ticket, i) => {
            if (i === index) {
              return {
                ...ticket,
                isForLoggedInUser: !ticket.isForLoggedInUser,
                ...(ticket.isForLoggedInUser
                  ? { firstName: '', lastName: '', email: '', phone: '' }
                  : user && {
                      firstName: user.firstName,
                      lastName: user.lastName,
                      email: user.email,
                      phone: user.phone,
                    }),
              };
            } else {
              return {
                ...ticket,
                isForLoggedInUser: false,
              };
            }
          });
          return updatedDetails;
        });
      };

    const expressCheckoutOptions = {
        // Specify a type per payment method
        // Defaults to 'buy' for Google and 'plain' for Apple
        buttonType: {
          googlePay: 'checkout',
          applePay: 'check-out'
        },
        // Specify a theme per payment method
        // Default theme is based on appearance API settings
        buttonTheme: {
          applePay: 'white-outline'
        },
        // Height in pixels. Defaults to 44. The width is always '100%'.
        buttonHeight: 55
      }

    const onReady = ({availablePaymentMethods}) => {
      if (!availablePaymentMethods) {
        // No buttons will show
      } else {
        // Optional: Animate in the Element
        setVisibility('initial');
      }
    };

    const onCancel = () => {
        elements.update({amount: totalPrice})
      };

      const onConfirm = async () => {
        setIsLoading(true);
      
        if (!stripe || !elements) {
          setIsLoading(false);
          return;
        }
      
        try {
          // Validate inputs
          for (let i = 0; i < ticketDetails.length; i++) {
            const { firstName, lastName, email, phone, isForLoggedInUser } = ticketDetails[i];
      
            if (!isForLoggedInUser) {
              if (!nameRegex.test(firstName) || !nameRegex.test(lastName)) {
                alert(`Please enter a valid name for Ticket ${i + 1}.`);
                setIsLoading(false);
                return;
              }
              if (!emailRegex.test(email)) {
                alert(`Please enter a valid email for Ticket ${i + 1}.`);
                setIsLoading(false);
                return;
              }
              if (!phoneRegex.test(phone)) {
                alert(`Please enter a valid 10-digit phone number for Ticket ${i + 1}.`);
                setIsLoading(false);
                return;
              }
            }
          }

          const tickets = ticketDetails.map((ticket) => ({
            firstName: ticket.firstName,
            lastName: ticket.lastName,
            email: ticket.email,
            phone: ticket.phone,
            isForLoggedInUser: ticket.isForLoggedInUser
          }));
      
          // Submit payment details collected by the Express Checkout Element
          const { error: submitError, paymentMethod } = await elements.submit();
          console.log(paymentMethod);
          if (submitError) {
            setErrorMessage('Error during elements.submit: ' + submitError.message);
            setIsLoading(false);
            return;
          }

          if (!clientSecret) {
            throw new Error('Failed to retrieve client secret.');
          }

          localStorage.setItem('ticketsToCreate', JSON.stringify(tickets));
      
          // Confirm the PaymentIntent using the details collected by the Express Checkout Element
          const { error, paymentIntent } = await stripe.confirmPayment({
            elements,
            clientSecret,
            confirmParams: {
              return_url: `${window.location.origin}/ticket-creation?fein=${fein}&barName=${encodeURIComponent(barName)}&barId=${barId}`,
            },
          });
      
          if (error) {
            throw new Error(error.message);
          }
      
          console.log('Payment successful: ', paymentIntent);
      
        } catch (error) {
          console.error('Error during payment confirmation:', error.message);
          localStorage.removeItem('ticketsToCreate');
          setErrorMessage('An error occurred during payment. Please try again.' + error.message);
        } finally {
          setIsLoading(false);
        }
      };                     

        const handleSubmit = async (event) => {
          event.preventDefault();
          setIsLoading(true);
      
          if (!stripe || !elements) {
            setIsLoading(false);
            return;
          }
      
          // Validate inputs
          for (let i = 0; i < ticketDetails.length; i++) {
            const { firstName, lastName, email, phone, isForLoggedInUser } = ticketDetails[i];
      
            if (!isForLoggedInUser) {
              if (!nameRegex.test(firstName) || !nameRegex.test(lastName)) {
                alert(`Please enter a valid name for Ticket ${i + 1}.`);
                setIsLoading(false);
                return;
              }
              if (!emailRegex.test(email)) {
                alert(`Please enter a valid email for Ticket ${i + 1}.`);
                setIsLoading(false);
                return;
              }
              if (!phoneRegex.test(phone)) {
                alert(`Please enter a valid 10-digit phone number for Ticket ${i + 1}.`);
                setIsLoading(false);
                return;
              }
            }
          }

          try {
            if (!clientSecret) {
              throw new Error('Failed to retrieve client secret.');
            }
      
            const cardElement = elements.getElement(CardElement);
            if (!cardElement) {
              alert('Payment method not initialized.');
              return;
            }
      
            // Confirm the payment
            const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
              payment_method: {
                card: cardElement,
              },
            });
      
            if (error) throw error;
      
            if (paymentIntent && paymentIntent?.status === 'succeeded') {
                await handleTicketCreation(paymentIntent.id);
                navigate("/hops");
            }
          } catch (error) {
            console.error('Payment Error:', error.message);
            setPaymentStatus('failed');
          } finally {
            setIsLoading(false);
          }
        };

      const handleTicketCreation = async (paymentIntentId) => {
        try {
            const tickets = ticketDetails.map((ticket) => ({
              firstName: ticket.firstName,
              lastName: ticket.lastName,
              email: ticket.email,
              phone: ticket.phone,
              isForLoggedInUser: ticket.isForLoggedInUser
            }));
    
          const response = await fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/createTicket`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-api-key': process.env.REACT_APP_BASE_API_KEY,
            },
            body: JSON.stringify({
                action: 'createTickets',
                paymentIntentId,
                fein,
                bar_id: barId,
                tickets,
                bar_name: barName,
              }),
          });
      
          const ticketData = await response.json();
    
          // Store tickets in localStorage for guest users
          if (ticketData.tickets) {
            if (!user) {
              const storedTickets = JSON.parse(localStorage.getItem('tickets')) || [];
              localStorage.setItem('tickets', JSON.stringify([...storedTickets, ...ticketData.tickets]));
            }
            setPaymentStatus('succeeded');
            closePayment();
          }
        } catch (error) {
          console.error('Ticket Creation Error:', error.message);
          setPaymentStatus('failed');
        }
      };

      if (!elements) {
        return (
            <div className="spinner-wrapper">
                <FaSpinner className="spinner" />
            </div>)
      }
  return (
    <div className="payment-form-overlay">
      <div className="payment-form-container" style={{visibility}}>
        <div className="payment-form-header">
            <FaTimes className="close-icon" onClick={closePayment} />
        </div>        
        <div className="payment-form">
          <h2>Enter Ticket Details</h2>
          {ticketDetails.map((ticket, index) => (
            <div key={index} className="ticket-entry">
              <h3>Ticket {index + 1}</h3>
              {user && (
                <div className="checkbox-container">
                  <input
                    type="checkbox"
                    id={`ticket-${index}`}
                    checked={ticket.isForLoggedInUser}
                    onChange={() => handleCheckboxChange(index)}
                  />
                  <label htmlFor={`ticket-${index}`}>Use my information</label>
                </div>
              )}
              {!ticket.isForLoggedInUser && (
                <div className="ticket-entry-item">
                  <input
                    type="text"
                    placeholder="First Name"
                    value={ticket.firstName}
                    onChange={(e) => handleInputChange(index, 'firstName', e.target.value)}
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    value={ticket.lastName}
                    onChange={(e) => handleInputChange(index, 'lastName', e.target.value)}
                  />
                  <input
                    type="email"
                    placeholder="Email"
                    value={ticket.email}
                    onChange={(e) => handleInputChange(index, 'email', e.target.value)}
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    value={ticket.phone}
                    onChange={(e) => handleInputChange(index, 'phone', e.target.value)}
                  />
                </div>
              )}
            </div>
          ))}
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                },
              },
            }}
          />
          <button type="submit" onClick={handleSubmit} disabled={!stripe || isLoading || !elements} className="pay-button">
           {isLoading ? 'Processing...' : `Pay $${totalPrice / 100}`}
          </button>
        </div>
        <p style={{ color: 'black', textAlign: 'center' }}>----------- OR -----------</p>
        <ExpressCheckoutElement
          options={expressCheckoutOptions}
          onConfirm={onConfirm}
          onReady={onReady}
          onCancel={onCancel}
        />
      </div>
      {errorMessage && <div>{errorMessage}</div>}
    </div>
  );
};

export default PaymentFormFour;