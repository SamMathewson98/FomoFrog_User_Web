import React, { useState, useContext } from 'react';
import '../index.css';
import { FaTimes } from 'react-icons/fa';
import { UserContext } from '../Contexts/UserContext';
import LoadingButton from './LoadingButton';
import { useNavigate } from 'react-router-dom';

const PasswordManagementModal = ({ isOpen, onClose }) => {
  const [passwords, setPasswords] = useState({
    currentPassword: '',
    newPassword: '',
    confirmNewPassword: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const { user } = useContext(UserContext);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPasswords((prevPasswords) => ({
      ...prevPasswords,
      [name]: value,
    }));
  };

  const handleSave = async () => {
    setIsLoading(true);
    // Validate passwords
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(passwords.newPassword) || !passwordRegex.test(passwords.confirmNewPassword) || !passwordRegex.test(passwords.currentPassword)) {
      window.alert('Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
      setIsLoading(false);
      return;
    }

    if (passwords.newPassword !== passwords.confirmNewPassword) {
      alert('New passwords do not match.');
      setIsLoading(false);
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found in local storage');
      window.alert('No user session found, please log in to change your password');
      setIsLoading(false);
      navigate("/");
      return;
    }

    try {
      // Call API to update the password using the email from user context
      const response = await fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/changePassword`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-api-key': process.env.REACT_APP_BASE_API_KEY
        },
        body: JSON.stringify({
          email: user.email,
          currentPassword: passwords.currentPassword,
          newPassword: passwords.newPassword,
        }),
      });

      if (response.ok) {
        alert('Password updated successfully!');
        setIsLoading(false);
        onClose();
      } else {
        console.error('Failed to change password:', response);
        alert('Failed to update password. Please try again later.');
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Error changing password:', error);
      alert('Server error. Please try again later.');
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2 className='modal-title'>Password Management</h2>
          <form className="contact-info-form">
            <label>Current Password</label>
            <input
              type="password"
              name="currentPassword"
              value={passwords.currentPassword}
              onChange={handleChange}
              className='input-field'
              required
            />
            <label>New Password</label>
            <input
              type="password"
              name="newPassword"
              value={passwords.newPassword}
              onChange={handleChange}
              className='input-field'
              required
            />
            <label>Confirm New Password</label>
            <input
              type="password"
              name="confirmNewPassword"
              value={passwords.confirmNewPassword}
              onChange={handleChange}
              className='input-field'
              required
            />
          </form>
          <button className={`button-primary ${isLoading ? 'loading' : ''}`} onClick={handleSave}>
          {isLoading ? <div className="spinner spinner-center"></div> : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PasswordManagementModal;