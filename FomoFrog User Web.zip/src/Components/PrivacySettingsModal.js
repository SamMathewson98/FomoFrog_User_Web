import React, { useState } from 'react';
import '../index.css';
import { FaTimes } from 'react-icons/fa';

const PrivacySettingsModal = ({ isOpen, onClose }) => {
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'public',
    dataSharing: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPrivacySettings((prevSettings) => ({
      ...prevSettings,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSave = () => {
    // Save logic here (e.g., call an API to save the updated privacy settings)
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2>Privacy Settings</h2>
          <form className="privacy-settings-form">
            <label>
              Profile Visibility
              <select
                name="profileVisibility"
                value={privacySettings.profileVisibility}
                onChange={handleChange}
              >
                <option value="public">Public</option>
                <option value="private">Private</option>
                <option value="friends">Friends Only</option>
              </select>
            </label>
            <label>
              <input
                type="checkbox"
                name="dataSharing"
                checked={privacySettings.dataSharing}
                onChange={handleChange}
              />
              Allow data sharing for personalized experience
            </label>
          </form>
          <button className="button-primary" onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
};

export default PrivacySettingsModal;