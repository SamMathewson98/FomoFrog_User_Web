import React, { useState } from 'react';
import '../index.css';
import { FaTimes } from 'react-icons/fa';

const AccountSecurityModal = ({ isOpen, onClose }) => {
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    loginAlerts: false,
  });

  const handleChange = (e) => {
    const { name, checked } = e.target;
    setSecuritySettings((prevSettings) => ({
      ...prevSettings,
      [name]: checked,
    }));
  };

  const handleSave = () => {
    // Save logic here (e.g., call an API to save the updated security settings)
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2>Account Security</h2>
          <form className="account-security-form">
            <label>
              <input
                type="checkbox"
                name="twoFactorAuth"
                checked={securitySettings.twoFactorAuth}
                onChange={handleChange}
              />
              Enable Two-Factor Authentication
            </label>
            <label>
              <input
                type="checkbox"
                name="loginAlerts"
                checked={securitySettings.loginAlerts}
                onChange={handleChange}
              />
              Receive Login Alerts
            </label>
          </form>
          <button className="button-primary" onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
};

export default AccountSecurityModal;