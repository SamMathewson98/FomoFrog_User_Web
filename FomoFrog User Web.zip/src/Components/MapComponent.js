import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import '../index.css';
import BarModal from './BarModal';

const MapComponent = ({ bars = [], userLocation }) => {
  const [selectedBar, setSelectedBar] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Function to create a circular icon for bars
  const createCustomIcon = (iconUrl) => {
    return new L.Icon({
      className: 'custom-marker-icon', // Add a class for styling
      iconUrl: iconUrl || '/FomoFrog logo.webp',
      html: `<div class="marker-wrapper">
             <img src="${iconUrl}" alt="Marker" class="marker-image" />
           </div>`,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
      popupAnchor: [0, -20],
    });
  };

  // Function to create the blue circle icon for user location
  const createUserLocationIcon = () => {
    return new L.DivIcon({
      className: 'user-location-icon',
      html: `<div style="
        width: 15px;
        height: 15px;
        background-color: #007bff;
        border: 3px solid #ffffff;
        border-radius: 50%;
        box-shadow: 0 0 8px rgba(0, 123, 255, 0.8);
        "></div>`,
    });
  };

  const handlePopupClick = (bar) => {
    setSelectedBar(bar);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedBar(null);
  };

  // Custom component to center map on user location
  const CenterMapOnUser = ({ location }) => {
    const map = useMap();
    map.setView(location, 13); // Center the map on user location with zoom level 13
    return null;
  };

  return (
    <div className="map-container" style={{ height: '100%', width: '100%' }}>
      <MapContainer center={userLocation} zoom={13} scrollWheelZoom={true} style={{ height: '100%', width: '100%' }}>
        <CenterMapOnUser location={userLocation} />
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />

        {/* User location marker */}
        <Marker position={userLocation} icon={createUserLocationIcon()}>
          <Popup>
            <div className="custom-popup-title">You are here</div>
          </Popup>
        </Marker>

        {/* Bar markers */}
        {bars.length > 0 &&
          bars.map((bar) => (
            <Marker
              key={bar.bar_id}
              position={[bar.latitude, bar.longitude]}
              icon={createCustomIcon(bar.icon_url)}
            >
              <Popup className="custom-popup">
                <div onClick={() => handlePopupClick(bar)} className="popup-content">
                  <div className="custom-popup-title">{bar.venueName}</div>
                  {bar.distance && (
                    <div className="custom-popup-distance">{`${bar.distance.toFixed(1)} miles away`}</div>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}
      </MapContainer>

      {/* Bar Modal */}
      {isModalOpen && selectedBar && (
        <BarModal bar={selectedBar} isOpen={isModalOpen} onClose={closeModal} />
      )}
    </div>
  );
};

export default MapComponent;