import React from 'react';
import '../index.css';

const InactiveTicketList = ({ tickets }) => {
  return (
    <div className="inactive-ticket-list">
      {tickets.map((ticket) => {
        const formattedPurchaseTime = new Date(ticket.datetime_purchased).toLocaleString('en-US', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        });

        return (
          <div key={ticket.ticketID} className="inactive-ticket">
            <div className="ticket-bar-name">Venue: {ticket.bar_name}</div>
            <div className="inactive-ticket-details">
              <div className="ticket-price">Price: ${ticket.price.toFixed(2)}</div>
              <div className="ticket-purchase-time">Purchased: {formattedPurchaseTime}</div>
              <div className="ticket-status">Status: {ticket.ticket_status}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default InactiveTicketList;