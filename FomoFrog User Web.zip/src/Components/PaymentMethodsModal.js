import React, { useState } from 'react';
import '../index.css';
import { FaTimes } from 'react-icons/fa';

const PaymentMethodsModal = ({ isOpen, onClose }) => {
  const [paymentMethods, setPaymentMethods] = useState([
    { id: 1, type: 'Credit Card', cardNumber: '**** **** **** 1234', expiryDate: '12/24' },
    { id: 2, type: 'Debit Card', cardNumber: '**** **** **** 5678', expiryDate: '10/23' },
  ]);

  const handleDelete = (id) => {
    setPaymentMethods(paymentMethods.filter((method) => method.id !== id));
  };

  const handleAddPaymentMethod = () => {
    // Logic to add a new payment method can be implemented here
    alert('Add Payment Method functionality coming soon!');
  };

  const handleSave = () => {
    // Save logic here (e.g., call an API to save the updated payment methods)
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2>Payment Methods</h2>
          <div className="payment-methods-list">
            {paymentMethods.map((method) => (
              <div key={method.id} className="payment-method">
                <div>{method.type}: {method.cardNumber} (Exp: {method.expiryDate})</div>
                <button className="button-secondary" onClick={() => handleDelete(method.id)}>Delete</button>
              </div>
            ))}
          </div>
          <button className="button-primary" onClick={handleAddPaymentMethod}>Add Payment Method</button>
          <button className="button-primary" onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethodsModal;