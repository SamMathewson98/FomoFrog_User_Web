import React, { useState, useContext } from 'react';
import '../index.css';
import { useNavigate } from 'react-router-dom';
import { FaTimes } from 'react-icons/fa';
import { UserContext } from '../Contexts/UserContext';

const DeleteAccountModal = ({ isOpen, onClose }) => {
  const [confirmation, setConfirmation] = useState('');
  const { user, logout } = useContext(UserContext);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleDelete = async () => {

    const token = localStorage.getItem('token');
        if (!token) {
          console.error('No token found in local storage');
          return;
        }

        setLoading(true);

    if (confirmation.toLowerCase() === 'delete') {
      try {
        // Call API to delete the user's account using the email from user context
        const response = await fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/deleteAccount`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.REACT_APP_BASE_API_KEY
          },
          body: JSON.stringify({ email: user.email }),
        });

        if (response.ok) {
          alert('Account deleted successfully.');
          logout();
          onClose();
          navigate('/');
        } else {
          alert('Failed to delete account. Please try again later.');
        }
      } catch (error) {
        alert('Server error. Please try again later.');
      }
    } else {
      alert('Please type "DELETE" to confirm account deletion.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <div className='contact-info-form'>
          <h2 className='modal-title'>Delete Account</h2>
          <p className='modal-title'>Are you sure you want to delete your account? This action cannot be undone.</p>
          <p className='modal-title'>To confirm, type "DELETE" in the box below:</p>
          <input
            type="text"
            value={confirmation}
            onChange={(e) => setConfirmation(e.target.value)}
            className="delete-confirmation-input"
          />
          </div>
          <button className="button-danger" onClick={handleDelete} disabled={loading}>{loading ? 'Deleting...' : 'Delete Account'}</button>
        </div>
      </div>
    </div>
  );
};

export default DeleteAccountModal;