import React, { useContext, useState, useEffect } from 'react';
import '../index.css';
import { UserContext } from '../Contexts/UserContext';
import { FaTimes } from 'react-icons/fa';
import axios from 'axios';

const ContactInfoModal = ({ isOpen, onClose }) => {
  const { user, setUser } = useContext(UserContext);
  const [contactInfo, setContactInfo] = useState({
    firstName: '',
    lastName: '',
    phone: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setContactInfo({
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        phone: user.phone || '',
      });
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setContactInfo((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    const { firstName, lastName, phone } = contactInfo;

    if (firstName === user?.firstName && lastName === user?.lastName && phone === user?.phone) {
      onClose();
      return;
    }

    const phoneRegex = /^\+?[0-9]{10,15}$/;
    if (!phoneRegex.test(phone)) {
      window.alert('Please enter a valid phone number.');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found in local storage');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/changeContactInfo`,
        { email: user.email, firstName, lastName, phone },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
          },
        }
      );

      if (response.status === 200) {
        setUser((prev) => ({ ...prev, firstName, lastName, phone }));
        window.alert('Successfully updated contact info');
        onClose();
      } else {
        console.error('Failed to change contact information:', response);
        alert('Failed to change contact information. Please try again later.');
      }
    } catch (error) {
      console.error('Error changing contact info:', error);
      alert('An error occurred while changing contact information. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2 className='modal-title'>Edit Contact Information</h2>
          <form className="contact-info-form">
            <label>First Name</label>
            <input
              type="text"
              name="firstName"
              placeholder="First Name"
              value={contactInfo.firstName}
              onChange={handleChange}
              className="input-field"
            />
            <label>Last Name</label>
            <input
              type="text"
              name="lastName"
              placeholder="Last Name"
              value={contactInfo.lastName}
              onChange={handleChange}
              className="input-field"
            />
            <label>Phone Number</label>
            <input
              type="text"
              name="phone"
              placeholder="Phone"
              value={contactInfo.phone}
              onChange={handleChange}
              className="input-field"
            />
          </form>
          <button className="button-primary" onClick={handleSave} disabled={loading}>
            {loading ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactInfoModal;