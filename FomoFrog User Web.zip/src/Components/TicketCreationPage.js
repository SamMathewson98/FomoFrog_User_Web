import React, { useEffect, useContext, useState } from 'react';
import { UserContext } from '../Contexts/UserContext';
import { FaSpinner } from 'react-icons/fa';
import { useNavigate, useLocation } from 'react-router-dom';
import '../index.css';

const TicketCreationPage = () => {
  const { user } = useContext(UserContext);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [completed, setCompleted] = useState(false);
  const [showMessage, setShowMessage] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams(location.search);
    const clientSecret = params.get('payment_intent_client_secret');
    const paymentIntent = params.get('payment_intent');
    const tickets = JSON.parse(localStorage.getItem('ticketsToCreate')) || [];
    const fein = params.get('fein');
    const barName = params.get('barName');
    const barId = params.get('barId');

    const handleTicketCreation = async (paymentIntent) => {
      try {
        const response = await fetch(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/createTicket`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
          },
          body: JSON.stringify({
            action: 'createTickets',
            paymentIntentId: paymentIntent,
            fein,
            bar_id: barId,
            tickets,
            bar_name: barName,
          }),
        });

        const ticketData = await response.json();

        // Store tickets in localStorage for guest users
        if (ticketData.tickets) {
          if (!user) {
            const storedTickets = JSON.parse(localStorage.getItem('tickets')) || [];
            localStorage.setItem('tickets', JSON.stringify([...storedTickets, ...ticketData.tickets]));
          }
        }

        setCompleted(true);
        setLoading(false);
        setTimeout(() => {
          setShowMessage(false);
          navigate("/hops");
        }, 2000);
      } catch (error) {
        console.error('Ticket Creation Error:', error.message);
        setError('There was an error processing your tickets. Please try again.');
        setLoading(false);
        setTimeout(() => {
          setShowMessage(false);
        }, 2000);
      }
    };

    if (paymentIntent) {
      handleTicketCreation(paymentIntent);
    } else {
      setError('Missing payment intent client secret.');
      setLoading(false);
      setTimeout(() => {
        setShowMessage(false);
      }, 2000);
    }
  }, [navigate, location.search, user]);

  return (
    <div className="home-page">
      {loading ? (
        <>
        <div className="spinner-wrapper">
          <FaSpinner className="spinner" />
        </div>
          <h1>Processing your tickets...</h1>
          </>
      ) : showMessage && error ? (
        <div className="error-message">
          <h1>{error}</h1>
          <button className='button-primary' onClick={()=> {navigate("/home")}}>Return to Home</button>
        </div>
      ) : showMessage && completed ? (
        <div className="success-message">
          <h1>Your tickets have been successfully processed!</h1>
        </div>
      ) : (
        <div></div>
      )}
    </div>
  );
};

export default TicketCreationPage;