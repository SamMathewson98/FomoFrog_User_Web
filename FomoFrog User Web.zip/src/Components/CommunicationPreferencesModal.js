import React, { useState } from 'react';
import '../index.css';
import LoadingButton from './LoadingButton';
import { FaTimes } from 'react-icons/fa';

const CommunicationPreferencesModal = ({ isOpen, onClose }) => {
  const [preferences, setPreferences] = useState({
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, checked } = e.target;
    setPreferences((prevPreferences) => ({
      ...prevPreferences,
      [name]: checked,
    }));
  };

  const handleSave = () => {
    // Save logic here (e.g., call an API to save the updated preferences)
    setIsLoading(true);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <FaTimes className="close-icon" style={{ color: 'var(--text-color)' }} onClick={onClose} />
        </div>
        <div className="modal-content">
          <h2 className='modal-title'>Communication Preferences</h2>
          <form className="communication-preferences-form">
            <label>
              <input
                type="checkbox"
                name="emailNotifications"
                checked={preferences.emailNotifications}
                onChange={handleChange}
              />
              Email Notifications
            </label>
            <label>
              <input
                type="checkbox"
                name="smsNotifications"
                checked={preferences.smsNotifications}
                onChange={handleChange}
              />
              SMS Notifications
            </label>
            <label>
              <input
                type="checkbox"
                name="pushNotifications"
                checked={preferences.pushNotifications}
                onChange={handleChange}
              />
              Push Notifications
            </label>
          </form>
          <button className={`button-primary ${isLoading ? 'loading' : ''}`} onClick={handleSave}>
          {isLoading ? <div className="spinner spinner-center"></div> : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CommunicationPreferencesModal;