import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaMapMarkerAlt, FaTicketAlt, FaUser } from 'react-icons/fa';
import '../index.css';

const NavBar = () => {
  const navigate = useNavigate();

  return (
    <div className='nav-wrapper'>
    <div className="nav-bar">
      <button onClick={() => navigate('/home')} className="nav-item">
        <FaMapMarkerAlt size={24} />
      </button>
      <button onClick={() => navigate('/hops')} className="nav-item">
        <FaTicketAlt size={24} />
      </button>
      <button onClick={() => navigate('/profile')} className="nav-item">
        <FaUser size={24} />
      </button>
    </div>
    </div>
  );
};

export default NavBar;
