import React from 'react';
import logo from './logo.svg';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';
import Login from './Pages/Login';
import './App.css';
import PasswordLogin from './Pages/PasswordLogin';
import CreateAccount from './Pages/CreateAccount';
import HomePage from './Pages/HomePage';
import HopsPage from './Pages/Hops';
import ProfilePage from './Pages/ProfilePage';
import ForgotPasswordPage from './Pages/ForgotPasswordPage';
import PasswordResetPage from './Pages/PasswordResetPage';
import TicketCreationPage from './Components/TicketCreationPage';

function App() {
  return (
    <React.StrictMode>
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/Login" element={<PasswordLogin />} />
          <Route path="/CreateAccount" element={<CreateAccount />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/hops" element={<HopsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/forgotpassword" element={<ForgotPasswordPage />} />
          <Route path="/resetpassword" element={<PasswordResetPage />} />
          <Route path="/ticket-creation" element={<TicketCreationPage />} />
        </Routes>
      </Router>
    </React.StrictMode>
  );
}

export default App;
