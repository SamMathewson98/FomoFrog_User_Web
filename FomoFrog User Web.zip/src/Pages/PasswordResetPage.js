import React, { useState } from 'react';
import '../index.css';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { FaArrowLeft } from 'react-icons/fa';

const PasswordResetPage = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Get the token from the URL parameters
  const resetToken = searchParams.get('token');

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Input validation
    if (password.length < 8) {
      setMessage('Password must be at least 8 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setMessage('Passwords do not match.');
      return;
    }

    setLoading(true);
    setMessage(null);

    try {
      // Make an API call to reset the password
      const response = await axios.post(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/resetPassword`, {
        resetToken,
        newPassword: password,
      }, {
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.REACT_APP_BASE_API_KEY
        },
      });

      if (response.status === 200) {
        setMessage('Password reset successfully! Redirecting to login...');
        setTimeout(() => navigate('/login'), 3000);
      } else {
        setMessage('Failed to reset password. Please try again later.');
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      setMessage('An error occurred while resetting your password. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container full-height">
      <div className="back-arrow" onClick={() => navigate('/login')}>
        <FaArrowLeft size={30} color="var(--text-color)" />
      </div>
      <div className="reset-password-form-wrapper">
        <h2 className='modal-title'>Reset Your Password</h2>
        {message && <div className="success-message">{message}</div>}
        <form onSubmit={handleSubmit} className="reset-password-form">
          <input
            type="password"
            placeholder="New Password"
            value={password}
            onChange={handlePasswordChange}
            className="input-field"
          />
          <input
            type="password"
            placeholder="Confirm New Password"
            value={confirmPassword}
            onChange={handleConfirmPasswordChange}
            className="input-field"
          />
          <button type="submit" className="button-primary" disabled={loading}>
            {loading ? 'Saving...' : 'Reset Password'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default PasswordResetPage;