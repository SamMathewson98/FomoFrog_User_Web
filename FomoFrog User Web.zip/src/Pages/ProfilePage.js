import React, { useState, useEffect, useContext } from 'react';
import '../index.css';
import { UserContext } from '../Contexts/UserContext';
import ContactInfoModal from '../Components/ContactInfoModal';
//import CommunicationPreferencesModal from '../Components/CommunicationPreferencesModal';
//import PaymentMethodsModal from '../Components/PaymentMethodsModal';
import PasswordManagementModal from '../Components/PasswordManagementModal';
import ChangeEmailModal from '../Components/ChangeEmailModal';
//import PrivacySettingsModal from '../Components/PrivacySettingsModal';
//import AccountSecurityModal from '../Components/AccountSecurityModal';
import DeleteAccountModal from '../Components/DeleteAccountModal';
import NavigationBar from '../Components/NavigationBar';
import { useNavigate } from 'react-router-dom';
import ContactSupportModal from '../Components/ContactSupportModal';
import ReviewPoliciesModal from '../Components/ReviewPoliciesModal';

const ProfilePage = () => {
  const [activeModal, setActiveModal] = useState(null);
  const { user, logout } = useContext(UserContext);
  const navigate = useNavigate();

  const openModal = (modalName) => {
    setActiveModal(modalName);
  };

  const closeModal = () => {
    setActiveModal(null);
  };

  const navigatePages = (page) => {
    navigate(page);
  };

  const handleLogout = () => {
    logout(); // Call your logout function
    navigate('/'); // Navigate to the home page
  };

  return (
    <div className="profile-page">
      {user ? (
        <>
          <div className="profile-tiles">
            <div className="profile-tile" onClick={() => openModal('contactInfo')}>Edit Contact Information</div>
            <div className="profile-tile" onClick={() => openModal('changeEmail')}>Edit Contact Email</div>
            {/*<div className="profile-tile" onClick={() => openModal('communicationPreferences')}>Communication Preferences</div>*/}
            {/*<div className="profile-tile" onClick={() => openModal('paymentMethods')}>Payment Methods</div>*/}
            <div className="profile-tile" onClick={() => openModal('passwordManagement')}>Password Management</div>
            <div className="profile-tile" onClick={() => openModal('reviewPolicies')}>Review FomoFrog Policies</div>
            <div className='profile-tile' onClick={() => openModal('support')}>Contact Support</div>
            <div className="profile-tile" onClick={() => openModal('deleteAccount')}>Delete Account</div>
          </div>
          <button className="button-logout" onClick={handleLogout}>Log Out</button>
        </>
      ) : (
        <div className="auth-buttons">
          <button className="button-primary" onClick={() => navigatePages('/Login')}>Log In</button>
          <button className="button-secondary" onClick={() => navigatePages('/CreateAccount')}>Create Account</button>
          <button className='button-secondary' onClick={() => openModal('support')}>Contact Support</button>
        </div>
      )}

      {/* Modals */}
      {activeModal === 'contactInfo' && <ContactInfoModal isOpen={true} onClose={closeModal} />}
      {activeModal === 'changeEmail' && <ChangeEmailModal isOpen={true} onClose={closeModal} />}
      {/*{activeModal === 'communicationPreferences' && <CommunicationPreferencesModal isOpen={true} onClose={closeModal} />}*/}
      {/*{activeModal === 'paymentMethods' && <PaymentMethodsModal isOpen={true} onClose={closeModal} />}*/}
      {activeModal === 'passwordManagement' && <PasswordManagementModal isOpen={true} onClose={closeModal} />}
      {activeModal === 'deleteAccount' && <DeleteAccountModal isOpen={true} onClose={closeModal} />}
      {activeModal === 'support' && <ContactSupportModal isOpen={true} onClose={closeModal} />}
      {activeModal === 'reviewPolicies' && <ReviewPoliciesModal isOpen={true} onClose={closeModal} />}
      <NavigationBar />
    </div>
  );
};

export default ProfilePage;