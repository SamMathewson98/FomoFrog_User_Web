import React, { useState } from 'react';
import '../index.css';
import axios from 'axios';
import { FaArrowLeft } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

       // Input validation
       if (!emailRegex.test(email)) {
        window.alert('Please enter a valid email.');
        return;
      }

    try {
      const response = await axios.post(`${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/forgotPassword`, {
        email,
      }, {
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.REACT_APP_BASE_API_KEY
        },
      });

      if (response.status === 200) {
        setMessage('If an account exists for this email, a password reset link has been sent. If you do not receive an email, please ensure you check your spam mailbox.');
      } else {
        setMessage('Something went wrong. Please try again later.');
      }
    } catch (error) {
      console.error('Error sending reset password email:', error);
      setMessage('An error occurred. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container full-height">
      <div className="back-arrow" onClick={() => navigate('/Login')}>
        <FaArrowLeft size={30} color="var(--text-color)" />
      </div>
      <div className="login-form-wrapper">
        <h2 className="modal-title">Forgot Password</h2>
        <p className="form-subtext modal-title">Enter your email address and we'll send you a link to reset your password.</p>
        <form onSubmit={handleSubmit} className="create-account-form">
          <input
            type="email"
            placeholder="Email Address"
            value={email}
            onChange={handleEmailChange}
            className="input-field"
          />
          <button type="submit" className="button-primary">
            {loading ? 'Sending...' : 'Send Reset Link'}
          </button>
        </form>
        {message && <p className="success-message">{message}</p>}
      </div>
    </div>
  );
};

export default ForgotPasswordPage;