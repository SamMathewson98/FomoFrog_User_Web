import React, { useState, useContext, useEffect, useCallback } from 'react';
import '../index.css';
import { useNavigate } from 'react-router-dom';
import { FaLock, FaArrowLeft } from 'react-icons/fa';
import axios from 'axios';
import { UserContext } from '../Contexts/UserContext';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const PasswordLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const { login } = useContext(UserContext);
  const navigate = useNavigate();

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = useCallback(async () => {
    setIsLoading(true);

    // Input validation
    if (!emailRegex.test(email)) {
      window.alert('Please enter a valid email.');
      setIsLoading(false);
      return;
    }

    if (!passwordRegex.test(password)) {
      window.alert(
        'Password must be at least 8 characters long, include one uppercase letter, one lowercase letter, one number, and one special character.'
      );
      setIsLoading(false);
      return;
    }

    try {
      // AWS API endpoint for authentication
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/login`,
        { email, password },
        {
          headers: {
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
            'Content-Type': 'application/json',
          },
        }
      );

      if (response.data.message === 'Login successful') {
        const userData = response.data.user;
        // Store JWT in local storage for 7 days
        localStorage.setItem('token', response.data.token);
        // Update user context with logged-in user information
        login(response.data.token, userData);
        // Redirect to home page
        navigate('/home');
      } else if (response.data.message === 'Missing or invalid email or password.') {
        window.alert('Missing or invalid email or password');
      } else if (response.status === 401) {
        window.alert('Incorrect password.');
      }
    } catch (error) {
      window.alert(error.response.data.message);
    } finally {
      setIsLoading(false);
    }
  }, [email, password, login, navigate]);

  const handleKeyPress = useCallback(
    (e) => {
      if (e.key === 'Enter') {
        e.preventDefault(); // Prevent default "Enter" key behavior
        handleSubmit();
      }
    },
    [handleSubmit]
  );  

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [handleKeyPress]);

  return (
    <div className="container full-height">
      <div className="back-arrow" onClick={() => navigate('/')}>
        <FaArrowLeft size={30} color="var(--text-color)" />
      </div>
      <div className="lock-icon-wrapper">
        <FaLock size={40} color="var(--accent-color)" />
      </div>
      <div className="login-form-wrapper">
        <form onSubmit={(e) => e.preventDefault()} className="login-form">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={handleEmailChange}
            className="input-field"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={handlePasswordChange}
            className="input-field"
            required
          />
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!email || !password || isLoading}
            className={`button-primary ${isLoading ? 'loading' : ''}`}
          >
            {isLoading ? <div className="spinner spinner-center"></div> : 'Login'}
          </button>
          <button className="button-secondary" onClick={() => navigate('/forgotpassword')}>
            Forgot Password
          </button>
        </form>
      </div>
    </div>
  );
};

export default PasswordLogin;