import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { FaSpinner } from 'react-icons/fa';
import ValidTicket from '../Components/ValidTicket';
import InactiveTicketList from '../Components/InactiveTicketList';
import { UserContext } from '../Contexts/UserContext';
import NavBar from '../Components/NavigationBar';
import '../index.css';

const HopsPage = () => {
  const { user } = useContext(UserContext); // Assuming user is available in context
  const [tickets, setTickets] = useState([]);
  const [activeTickets, setActiveTickets] = useState([]);
  const [inactiveTickets, setInactiveTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const response = await axios.post(
          `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/getHops`,
          { email: user?.email }, // Sending email in the POST body
          {
            headers: {
              'Content-Type': 'application/json',
              'x-api-key': process.env.REACT_APP_BASE_API_KEY,
              'authorization': `Bearer ${localStorage.getItem('token')}`, // Optional JWT
            },
          }
        );

        if (response.status === 200) {
          const allTickets = response.data.tickets;
          const now = new Date();

          // Separate active and inactive tickets
          const active = [];
          const inactive = [];

          allTickets.forEach((ticket) => {
            const invalidDate = new Date(ticket.datetime_invalid);
            if (invalidDate > now && ticket.ticket_status === 'Active') {
              active.push(ticket);
            } else {
              inactive.push(ticket);
            }
          });

          setTickets(allTickets);
          setActiveTickets(active);
          setInactiveTickets(inactive);
        } else {
          console.error('Failed to fetch tickets:', response);
        }
      } catch (error) {
        console.error('Error fetching tickets:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTickets();
  }, [user?.email]);

  return (
    <div className="hops-page">
      <h1 className="modal-title">Your Active Hops</h1>
      {loading ? (
        <div className="spinner-wrapper">
          <FaSpinner className="spinner" />
        </div>
      ) : activeTickets.length > 0 ? (
        <div className='slider-container'>
        <ValidTicket tickets={activeTickets} />
        </div>
      ) : (
        <div className="no-tickets">You have no active hops! Don't miss out, purchase a hop pass today!</div>
      )}
      <div className="inactive-ticket-section scrollable-container">
        <h2 className="modal-title">Inactive Hops</h2>
        {loading ? (
          <div className="spinner-wrapper">
            <FaSpinner className="spinner" />
          </div>
        ) : inactiveTickets.length > 0 ? (
          <InactiveTicketList tickets={inactiveTickets} />
        ) : (
          <div className="no-tickets">You have no inactive hops</div>
        )}
      </div>
      <NavBar />
    </div>
  );
};

export default HopsPage;