import React, { useEffect, useState, useRef } from 'react';
import '../index.css';
import axios from 'axios';
import { FaSpinner } from 'react-icons/fa';
import NavigationBar from '../Components/NavigationBar';
import MapComponent from '../Components/MapComponent';
import BarListComponent from '../Components/BarListComponent';

const HomePage = () => {
  const [bars, setBars] = useState(null);
  const [userLocation, setUserLocation] = useState([32.7767, -96.7970]); // Default to downtown Dallas
  const [loading, setLoading] = useState(true);

  // Track if the bars API call is already in progress
  const locationFetched = useRef(false); 

  useEffect(() => {
    // Fetch user location on mount if not already fetched
    if (!locationFetched.current) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation([latitude, longitude]);
          locationFetched.current = true; // Mark location as fetched
        },
        (error) => {
          console.error("Error getting user's location: ", error);
          locationFetched.current = true; // Proceed even if location fails
        }
      );
    }
  }, []); // Run once to fetch user location

  useEffect(() => {
    const fetchBars = async () => {
      setLoading(true);
      const storedBars = JSON.parse(localStorage.getItem('bars'));
      const lastFetched = localStorage.getItem('barsLastFetched');

      if (storedBars && lastFetched && Date.now() - lastFetched < 300000) {
        // Use stored bars if they are fresh
        setBars(storedBars);
        setLoading(false);
      } else {
        try {
          const response = await axios.post(
            `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/getBars`,
            {
              userLocation,
            },
            {
              headers: {
                'Content-Type': 'application/json',
                'x-api-key': process.env.REACT_APP_BASE_API_KEY,
              },
            }
          );

          if (response.status === 200) {
            setBars(response.data.bars);
            localStorage.setItem('bars', JSON.stringify(response.data.bars));
            localStorage.setItem('barsLastFetched', Date.now());
          } else {
            console.error('Failed to fetch bars from API');
          }
        } catch (error) {
          console.error('Error fetching bars: ', error);
        } finally {
          setLoading(false);
        }
      }
    };

    // Fetch bars whenever userLocation changes
    fetchBars();
  }, [userLocation]); // Add userLocation as a dependency

  return (
    <div className="home-page">
      {loading ? (
        <div className="spinner-wrapper">
          <FaSpinner className="spinner" />
        </div>
      ) : (
        <>
          <div className="map-section">
            {bars && bars.length > 0 ? <MapComponent bars={bars} userLocation={userLocation} /> : null}
          </div>
          <div className="bar-list-section">
            {bars && bars.length > 0 ? (
              <BarListComponent bars={bars} userLocation={userLocation} />
            ) : (
              <div className="no-bars-message">No Bars Yet! Hope you can hop soon</div>
            )}
          </div>
        </>
      )}
      <NavigationBar />
    </div>
  );
};

export default HomePage;