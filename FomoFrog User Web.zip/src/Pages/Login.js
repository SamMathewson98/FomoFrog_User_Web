import React, { useEffect, useContext } from 'react';
import '../index.css';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../Contexts/UserContext';

const Login = () => {
  const navigate = useNavigate();
  const { login } = useContext(UserContext);

  useEffect(() => {
    // Check local storage for user and token
    const storedUser = localStorage.getItem('user');
    const storedToken = localStorage.getItem('token');

    if (storedUser && storedToken) {
      // Automatically log in the user using the stored data
      login(storedToken, JSON.parse(storedUser));
      navigate('/home');
    }
  }, [login, navigate]);

  const navigatePages = (page) => {
    navigate(page);
  };

  return (
    <div className="container full-height">
      <div className="logo-wrapper">
        <img src="/FomoFrog logo.webp" alt="Logo" className="logo" />
      </div>
      <div className='title'>
        <h1 className='title-text'>FomoFrog</h1>
      </div>
      <div className="button-wrapper">
        <button className="button-primary" onClick={() => navigatePages('/Login')}>Login</button>
        <button className="button-secondary glassmorphic" onClick={() => navigatePages('/Home')}>Continue as Guest</button>
        <button className="button-secondary glassmorphic" onClick={() => navigatePages('/CreateAccount')}>Create an Account</button>
      </div>
    </div>
  );
};

export default Login;