import React, { useState, useContext } from 'react';
import '../index.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FaArrowLeft } from 'react-icons/fa';
import { UserContext } from '../Contexts/UserContext';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const CreateAccount = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [termsViewed, setTermsViewed] = useState(false);
  const [privacyPolicyAccepted, setPrivacyPolicyAccepted] = useState(false);
  const [privacyPolicyViewed, setPrivacyPolicyViewed] = useState(false);

  const { login } = useContext(UserContext);
  const navigate = useNavigate();

  const termsUrl = `${process.env.REACT_APP_TERMS_AND_CONDITIONS}FomoFrog_Terms_and_Conditions.pdf`;
  const privacyPolicyUrl = `${process.env.REACT_APP_PRIVACY_POLICY}FomoFrog_Privacy_Policy.pdf`;

  const handleTermsClick = () => {
    setTermsViewed(true);
    window.open(termsUrl, '_blank'); // Opens the terms in a new tab
  };

  const handlePrivacyPolicyClick = () => {
    setPrivacyPolicyViewed(true);
    window.open(privacyPolicyUrl, '_blank'); // Opens the terms in a new tab
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Input validation
    if (!emailRegex.test(email)) {
      window.alert('Please enter a valid email.');
      setIsLoading(false);
      return;
    }

    const phoneRegex = /^\+?[0-9]{10,15}$/;
    if (!phoneRegex.test(phoneNumber)) {
      window.alert('Please enter a valid phone number.');
      setIsLoading(false);
      return;
    }

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
      window.alert(
        'Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.'
      );
      setIsLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      window.alert('Passwords do not match.');
      setIsLoading(false);
      return;
    }

    if (!termsAccepted) {
      window.alert('You must agree to the Terms and Conditions to create an account.');
      setIsLoading(false);
      return;
    }

    if (!privacyPolicyAccepted) {
      window.alert('You must agree to the FomoFrog Privacy Policy to create an account.');
      setIsLoading(false);
      return;
    }

    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_AWS_URL}/${process.env.REACT_APP_STAGE}/createUserAccount`,
        {
          firstName,
          lastName,
          email,
          phone: phoneNumber,
          password,
        },
        {
          headers: {
            'x-api-key': process.env.REACT_APP_BASE_API_KEY,
            'Content-Type': 'application/json',
          },
        }
      );

      if (response.status === 201) {
        login(response.data.token, { firstName, lastName, email, phoneNumber });
        navigate('/home');
      } else {
        window.alert('There was an issue creating your account. Please try again later.');
      }
    } catch (error) {
      window.alert('Server issue. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="home-page">
      <div className="back-arrow" onClick={() => navigate('/')}>
        <FaArrowLeft size={30} color="var(--text-color)" />
      </div>
      <div className="create-account-form-wrapper">
        <form onSubmit={handleSubmit} className="create-account-form">
          <input
            type="text"
            placeholder="First Name"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="input-field"
            required
          />
          <input
            type="text"
            placeholder="Last Name"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="input-field"
            required
          />
          <input
            type="email"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input-field"
            required
          />
          <input
            type="text"
            placeholder="Phone Number"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            className="input-field"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
            required
          />
          <input
            type="password"
            placeholder="Re-enter Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="input-field"
            required
          />
          <div className="terms-container">
                <div className='term-group'>
                <input
                  type="checkbox"
                  id="terms-checkbox"
                  checked={termsAccepted}
                  onChange={() => setTermsAccepted((prev) => !prev && termsViewed)}
                  disabled={!termsViewed}
                />
                <label htmlFor="terms-checkbox">
                  I agree to the{' '}
                  <span className="terms-link" onClick={handleTermsClick}>
                    Terms and Conditions
                  </span>
                </label>
                </div>
                <div className='term-group'>
                <input
                  type="checkbox"
                  id="terms-checkbox"
                  checked={privacyPolicyAccepted}
                  onChange={() => setPrivacyPolicyAccepted((prev) => !prev && privacyPolicyViewed)}
                  disabled={!privacyPolicyViewed}
                />
                <label htmlFor="privacy-checkbox">
                  Review the{' '}
                  <span className="terms-link" onClick={handlePrivacyPolicyClick}>
                    FomoFrog Privacy Policy
                  </span>
                </label>
                </div>
          </div>
          <button type="submit" className={`button-primary ${isLoading ? 'loading' : ''}`}>
            {isLoading ? <div className="spinner spinner-center"></div> : 'Create Account'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateAccount;